package com.tns.placementservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
